#! /bin/bash
mvn clean && mvn package -DskipTests
